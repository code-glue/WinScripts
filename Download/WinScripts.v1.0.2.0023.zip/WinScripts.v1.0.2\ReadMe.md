﻿WinScripts
==========

Various scripts for automating and tweaking Windows I've created/collected/assimilated over the years.

___
### AdbSuPull.bat
Copies files/directories from a rooted Android device to a Windows path.  
The files are temporarily copied to the directory "" on the device.  
The Android device must have enough free space to allow this operation.  

**Usage:**  

    AdbSuPull RemotePath [LocalPath]  

      RemotePath   Specifies the path to the file or directory on  
                   the rooted Android device.  

      LocalPath    Optionally specifies the destination path. This can be a  
                   Windows local path (C:\folder) or a UNC path  
                   (\\server\share).  
                   Defaults to adbSuPull_%UserName%_%TimeStamp%  
                   in the current working directory.  

___
### AddBinaryFileExtension.bat
Adds a NULL filter to the given file extension, telling the search indexer to ignore the file's contents.  

**Usage:**  

    AddBinaryFileExtension [[.]Extension]  

      Extension    The name of the extension to add, optionally prefixed by ".".  
                   Omit to prompt for the extension.  

**Examples:**

      C:\>AddBinaryFileExtension  
        Prompts for the file extension.  

      C:\>AddBinaryFileExtension "exe"  
        Adds a NULL handler for the .exe file extension.  

      C:\>AddBinaryFileExtension ".bin"  
        Adds a NULL handler for the .bin file extension.  

___
### AddCommonBinaryFileExts.bat
Adds a NULL handler for the following file extensions, telling the search indexer to ignore the file's contents.  

**Usage:**  

    .386.aif.aifc.aiff.aps.art.asf.au.avi.ba.baml.bi.bin.bkf.bmp.bsc.bti.cache.cda.cgm.cod.com.cpl.cpt.cub.cur.dax.dbg.dca.dct.desklink.dex.dgn.dib.dll.dl_.drv.drx.dvx.dwg.emf.eng.eps.etp.exe.exp.ex_.eyb.fnd.fnt.fon.ghi.gif.hdp.icm.ico.igr.ilk.imc.ino.ins.inv.in_.jbf.jds.jfif.jpe.jpeg.jpg.key.latex.ldb.lib.m14.m1v.ma.mapimail.mdb.mdb2.mid.midi.mmf.mov.movie.mp2.mp2v.mp3.mpa.mpe.mpeg.mpg.mpp.mpv2.mshc.msm.mso.mv.mydocs.ncb.o.obj.obs.ocx.oc_.opt.par.pc6.pcd.pch.pdb.pds.pic.pid.pma.pmc.PML.pmr.png.ppn.psd.pth.pvk.res.resources.rle.rmi.rose.rpc.rsc.rsp.sbr.sc2.scd.sch.sit.snd.sr_.sym.sys.sy_.tap.tbl.tlb.tsp.ttc.ttf.vbx.vue.vxd.wav.wax.wdp.wlt.wm.wma.wmf.wmp.wmv.wmx.wmz.wsi.wsz.wvx.xesc.xix.xor.z96.zfsendtotarget.zvf  

    AddCommonBinaryFileExts <No Parameters>  

___
### AddCommonTextFileExts.bat
Adds a plain text handler for the following file extensions, allowing files with the extension to be indexed, searched, and easily opened in any text editor:  

**Usage:**  

    .accessoracsadaadbaddinadsahkamammoarenaasasaascasmaspatrau3autauxawkaxlbasbash_historybatbhcbcfbodybotbshccameracatcbdcblcccdcdbcdccdfcfgcfmcgiclsclwcmakecmdcnfcntcobconfconfigcppcscsdlcsprojcsscsvctlcuecxxddatasourcedefdefsdfmdiffdizdobdocbookdotsettingsdjsdoxdpkdprdsmdspdsrdswdtddtldxfebsecoedgedmxefxenterrff2kf90f95fdfdffiltersfglfifforframesfrmg2skingametypegenerategitgitattributesgitconfiggitignoregitmodulesgoregradlegschhhhhchhkhhphmhpjhpphshtahtaccesshtdhtmhtmlhtpasswdhtthudhxahxchxkhxthxxidlidxilimlimpactsincinfiniinlinstanceinviewiprislissitclitemiwsjavajmconfigjnljpojsjsonjsfljspkixkmllaslhsliclinqlisplistlitcoffeeloglreflsplstluamm4makmanifestmapmapcyclemastermaterialmcmdmdlmenumetmetagenmiscentsmissionmkmkemlmlimnumptmsmsgsrcmshamslmstmxnamenatvisnavnfonpcnshnsintobjectivesodloraorderedtestoutfittingpagpaspatchpcfphpphp3php4phtmlperplplayerplnplxpmpopodportablepotposesppppkprjproprojpropertiespropsprppsps1ps1xmlpsc1psm1ptlpubpypyprojpywq3asmqe4rrbrbwrcrc2rdfrdprecentregrejrepresxrgergsrgtrmdrqerqprulrulesetsamsamplescmscriptsessettingssfshshlshadershfbprojshockshtmshtmlsifsklslnsmasmdsmlsnippetspspbspecspssqlssssdlststrstystypesubsuitsunsvsvgsvhsxlttargetstclteamsterraintestrunconfigtestsettingstexthemethytlhtlitmplttoctpltrxtsbttttincludetuituotxtuiurluservvbvbgvbpvbprojvbrvbsvbwvcprojvcsvcxprojvdprojvhvhdvhdlvoicevscontentvsdirvsmdivspropsvspsccvssettingsvsssccvstdirvsthemevszvtsvxmlvwswixlibwixobjwixprojwmlwntwpnwriwsdlwsfwxlwxsxamlxdcxhtmlxlfxliffxmlxmtxrcxsdxslxsltxsmlxulyml  

    AddCommonTextFileExts <No Parameters>  

___
### AddHtmlFileExtension.bat
Adds a plain text handler to the given file extension, allowing files with the extension to be indexed, searched, and easily opened in any text editor.  

**Usage:**  

    AddHtmlFileExtension [[.]Extension]  

      Extension    The name of the extension to add, optionally prefixed by ".".  
                   Use "." for files without an extension.  
                   Omit to prompt for the extension.  

**Examples:**

      C:\>AddHtmlFileExtension  
        Prompts for the file extension.  

      C:\>AddHtmlFileExtension "txt"  
        Adds a plain text handler for the .txt file extension.  

      C:\>AddHtmlFileExtension ".txt"  
        Adds a plain text handler for the .txt file extension.  

      C:\>AddHtmlFileExtension .  
        Adds a plain text handler for files without an extension.  

___
### AddTextFileExtension.bat
Adds a plain text handler to the given file extension, allowing files with the extension to be indexed, searched, and easily opened in any text editor.  

**Usage:**  

    AddTextFileExtension [[.]Extension]  

      Extension    The name of the extension to add, optionally prefixed by ".".  
                   Use "." for files without an extension.  
                   Omit to prompt for the extension.  

**Examples:**

      C:\>AddTextFileExtension  
        Prompts for the file extension.  

      C:\>AddTextFileExtension "txt"  
        Adds a plain text handler for the .txt file extension.  

      C:\>AddTextFileExtension ".txt"  
        Adds a plain text handler for the .txt file extension.  

      C:\>AddTextFileExtension .  
        Adds a plain text handler for files without an extension.  

___
### AppPathAdd.bat
Allows a program/file to be opened from the "Run" dialog window using an alias.  

**Usage:**  

    AppPathAdd [Path [Alias]]  

      Path   Path to the program/file that will be run/opened.  
      Alias  Name that will be entered into the Run dialog window.  
             If excluded, defaults to the file's name.  

**Examples:**

      C:\>AppPathAdd  
        Prompts for the file path and alias.  

      C:\>AppPathAdd "C:\Program Files (x86)\NotePad++\notepad++.exe"  
        Runs Notepad++ when "notepad++" or "notepad++.exe" is entered.  

      C:\>AppPathAdd "C:\Program Files (x86)\NotePad++\notepad++.exe" npp  
        Runs Notepad++ when "npp" or "npp.exe" is entered.  

___
### AppPathRemove.bat
Prevents a program/file from being opened from the "Run" dialog window using its alias.  

**Usage:**  

    AppPathRemove [Alias[.exe]]  

      Alias    The name of the alias to remove, optionally followed by ".exe".  

**Examples:**

      C:\>AppPathRemove  
        Prompts for the alias.  

      C:\>AppPathRemove "npp"  
        Removes the "npp.exe" alias from the registry.  

      C:\>AppPathRemove "npp.exe"  
        Removes the "npp.exe" alias from the registry.  

___
### Bell.bat
Plays the sound of the bell control signal (ASCII character 7).  

**Usage:**  

    Bell <No Parameters>  

___
### ClearIconCache.bat
Clears the icon cache.  

**Usage:**  

    ClearIconCache <No Parameters>  

___
### DirExists.bat
Determines whether the given path refers to an existing directory.  
Sets the ErrorLevel variable to 0 if the directory exists; otherwise, 1.  

**Usage:**  

    DirExists Path  

      Path    The path to test.  

**Examples:**

      C:\>DirExists  
        Sets %ErrorLevel% to 1.  

      C:\>DirExists "C:\Windows"  
        Sets %ErrorLevel% to 0. Directory exists.  

      C:\>DirExists "C:\"  
        Sets %ErrorLevel% to 0. Drives are considered directories.  

      C:\>DirExists "C:\Windows\notepad.exe"  
        Sets %ErrorLevel% to 1. Path exists but is a file.  

___
### FileExists.bat
Determines whether the given path refers to an existing file.  
Sets the ErrorLevel variable to 0 if the file exists; otherwise, 1.  

**Usage:**  

    FileExists Path  

      Path    The path to test.  

**Examples:**

      C:\>FileExists  
        Sets %ErrorLevel% to 1.  

      C:\>FileExists "C:\Windows\notepad.exe"  
        Sets %ErrorLevel% to 0. File exists.  

      C:\>FileExists "C:\Windows"  
        Sets %ErrorLevel% to 1. Path exists but is a directory.  

___
### GetTextEditor.bat
Gets the default editor for text files.  

**Usage:**  

    GetTextEditor <No Parameters>  

___
### KillAdb.bat
Kills all instances of adb.exe.  

**Usage:**  

    KillAdb <No Parameters>  

___
### PauseGui.bat
Suspends processing of a batch program if run from explorer.exe; otherwise, does nothing.  
To prevent pausing, set DisablePauseGui=1  

**Usage:**  

    PauseGui [PathToCallingScript]  

      PathToCallingScript    The full path to the calling script.  
                             If omitted, the path to this script is used.  

**Examples:**
      Given the file AnyOtherFile.bat:  
         @echo off  
         call PauseGui "%~f0"  

      C:\>AnyOtherFile.bat  
         No operation is performed.  

      If AnyOtherFile.bat is opened from explorer.exe:  
         Press any key to continue . . .  

___
### RegKeyExists.bat
Determines whether the given path refers to an existing registry key.  
Sets the ErrorLevel variable to 0 if the registry key exists; otherwise, 1.  

**Usage:**  

    RegKeyExists KeyName  

      KeyName  [\\Machine\]FullKey  
               Machine - Name of remote machine, omitting defaults to the  
                         current machine. Only HKLM and HKU are available on  
                         remote machines  
               FullKey - in the form of ROOTKEY\SubKey name  
                    ROOTKEY - [ HKLM | HKCU | HKCR | HKU | HKCC ]  
                    SubKey  - The full name of a registry key under the  
                              selected ROOTKEY  

**Examples:**

      C:\>RegKeyExists  
        Sets %ErrorLevel% to 1.  

      C:\>RegKeyExists "HKCR"  
        Sets %ErrorLevel% to 0. Registry key exists.  

      C:\>RegKeyExists "HKCU\BadKeyName"  
        Sets %ErrorLevel% to 1. Registry key does not exist.  

___
### RegQuery.bat
Returns a list of the next tier of subkeys and entries that are located under a  
specified subkey in the registry.  

**Usage:**  

    RegQuery KeyName [LocalPath]  

      KeyName  [\\Machine\]FullKey  
               Machine - Name of remote machine, omitting defaults to the  
                         current machine. Only HKLM and HKU are available on  
                         remote machines  
               FullKey - in the form of ROOTKEY\SubKey name  
                    ROOTKEY - [ HKLM | HKCU | HKCR | HKU | HKCC ]  
                    SubKey  - The full name of a registry key under the  
                              selected ROOTKEY  

      LocalPath    Optionally specifies the destination path. This can be a  
                   Windows local path (C:\folder) or a UNC path  
                   (\\server\share).  
                   Defaults to adbSuPull_%UserName%_%TimeStamp%  
                   in the current working directory.  

___
### RestartAdb.bat
Kills all instances of adb.exe and restarts it.  

**Usage:**  

    RestartAdb <No Parameters>  

___
### RestartExplorer.bat
Restarts explorer.exe.  

**Usage:**  

    RestartExplorer [/Q]  

      /Q    Quiet mode, do not ask if ok to restart explorer.exe.  

**Examples:**

      C:\>RestartExplorer  
        Prompts to restart explorer.exe.  

      C:\>RestartExplorer /q  
        Restarts explorer.exe without prompting.  

___
### SetTextEditor.bat
Sets the default editor for text files.  

**Usage:**  

    SetTextEditor ExePath  

      ExePath    The path of the program to set as the default text editor.  

**Examples:**

      C:\>SetTextEditor  
        Prompts for the path.  

      C:\>SetTextEditor "C:\Program Files (x86)\Notepad++\notepad++.exe"  
        Sets Notepad++ as the default text editor.  

___
### ShortcutSuffixDisable.bat
Disables the setting to append " - Shortcut" on new shortcuts.  
Requires explorer.exe to be restarted.  

**Usage:**  

    ShortcutSuffixDisable [/Y | /N]  

      /Y    Restart explorer.exe.  
      /N    Do not restart explorer.exe.  

**Examples:**

      C:\>ShortcutSuffixDisable  
        Disables the setting to append " - Shortcut" on new shortcuts,  
        and prompts to restart explorer.exe.  

      C:\>ShortcutSuffixDisable /y  
        Disables the setting to append " - Shortcut" on new shortcuts,  
        and restarts explorer.exe without prompting.  

      C:\>ShortcutSuffixDisable /n  
        Disables the setting to append " - Shortcut" on new shortcuts,  
        and does not restart explorer.exe.  

___
### ShortcutSuffixEnable.bat
Enables the setting to append " - Shortcut" on new shortcuts.  
Requires explorer.exe to be restarted.  

**Usage:**  

    ShortcutSuffixEnable [/Y | /N]  

      /Y    Restart explorer.exe.  
      /N    Do not restart explorer.exe.  

**Examples:**

      C:\>ShortcutSuffixEnable  
        Enables the setting to append " - Shortcut" on new shortcuts,  
        and prompts to restart explorer.exe.  

      C:\>ShortcutSuffixEnable /y  
        Enables the setting to append " - Shortcut" on new shortcuts,  
        and restarts explorer.exe without prompting.  

      C:\>ShortcutSuffixEnable /n  
        Enables the setting to append " - Shortcut" on new shortcuts,  
        and does not restart explorer.exe.  

___
### StringLength.bat
2  

___
### test.bat
a:%a  
B:%b  
c:%c  
Value Name = DefaultColor  
Value Type = REG_DWORD  
Value Value = 0x0  
